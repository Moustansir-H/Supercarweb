<!--Debut footer-->
<footer>
  <div class="p-5 container-fluid" id="arriere" style="background-image: url(../img/Carbo.jpg);">
    <center><img class="Logo" src="../img/Logo.png" width="300px" /></center>
    <br />
    <hr size="8" color="white" />
    <br /><br /><br />
    <div class="row">
      <div class="col-sm-3 mb-3 mb-sm-0 text-light">
        <a class="link-light" href="../contact/contact.php" style="font-size: 120%;">Contactez-nous</a>
      </div>
      <div class="col-sm-3 text-light">
        <a class="link-light" href="./voiture/voiture.php" style="font-size: 120%;">Modèles</a><br /><br />
        <a class="link-light link-underline-opacity-0" href="../voiture/BMW/modelebmw.php">BMW</a><br />
        <a class="link-light link-underline-opacity-0" href="../voiture/Nissan/modelenissan.php">Nissan</a><br />
        <a class="link-light link-underline-opacity-0" href="../voiture/Ford/modeleford.php">Ford</a><br />
        <a class="link-light link-underline-opacity-0" href="../voiture/Porsche/modele Porsche.php">Porshe</a>
      </div>
      <div class="col-sm-3 text-light">
        <a class="link-light" href="../documents/conditions/conditions.php" style="font-size: 120%;">Confidentialite et mention legale</a>
      </div>
      <div class="col-sm-3 text-light">

      </div>
    </div>
    <br />
    <hr size="8" color="white" />
    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-9 text-light d-flex">
          <p>Copyright © 2024 SuperCar</p>
        </div>
        <div class="col-sm-3 d-flex flex-row-reverse gap-3">
          <a href="#">
            <img class="Logom" src="../img/Instagram_Glyph_White.png" width="30px" /></a>
          <a href="#">
            <img class="Logom" src="../img/Facebook_Logo_Secondary.png" width="30px" /></a>
          <a href="#">
            <img class="Logom" src="../img/logo-white.png" width="30px" /></a>
        </div>
      </div>
    </div>
  </div>
</footer>
<!--Fin footer-->