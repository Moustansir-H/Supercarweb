<?php
session_start();
include("dbserver_connect.php");

// Récupération des données du formulaire
$utilisateur = mysqli_real_escape_string($bdd, $_POST["Utilisateur"]);
$nom = mysqli_real_escape_string($bdd, $_POST["Nom"]);
$prenom = mysqli_real_escape_string($bdd, $_POST["Prenom"]);
$email = mysqli_real_escape_string($bdd, $_POST["Email"]);
$tel = $_POST["Tel"];
$mdp = $_POST["Mdp"];
$cmdp = $_POST["cmotdepasse"];

// Vérification que les mots de passe correspondent
if ($mdp !== $cmdp) {
    $_SESSION['status'] = "Les mots de passe ne correspondent pas";
    $_SESSION['status_code'] = "error";
    header('Location: ../../inscription/inscription.php');
    exit();
}

// Appel de la procédure stockée
$query = "CALL inscription_client(?, ?, ?, ?, ?, ?, @result)";
$stmt = mysqli_prepare($bdd, $query);

if ($stmt) {
    mysqli_stmt_bind_param(
        $stmt,
        "ssssis",
        $utilisateur,
        $nom,
        $prenom,
        $email,
        $tel,
        $mdp
    );

    mysqli_stmt_execute($stmt);

    // Récupération du résultat
    $result_query = mysqli_query($bdd, "SELECT @result AS message");
    $result = mysqli_fetch_assoc($result_query);

    // Traitement du résultat
    list($type, $message) = explode(':', $result['message'], 2);

    $_SESSION['status'] = $message;
    $_SESSION['status_code'] = strtolower($type);

    if ($type === 'SUCCES') {
        header('Location: ../../inscription/connexion.php');
    } else {
        header('Location: ../../inscription/inscription.php');
    }

    mysqli_stmt_close($stmt);
} else {
    $_SESSION['status'] = "Erreur technique lors de l'inscription";
    $_SESSION['status_code'] = "error";
    header('Location: ../../inscription/inscription.php');
}

mysqli_close($bdd);
