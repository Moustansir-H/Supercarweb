<?php session_start(); ?>
<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Demande d'essai de voiture</title>
  <link href="essai.css" rel="stylesheet" />
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
    rel="stylesheet" />
</head>

<body>
  <!--Debut nav-->
  <nav
    class="navbar navbar-expand-lg fixed-top"
    id="arriere"
    style="background-image: url(../img/Carbo.jpg)">
    <div class="container-fluid justify-content-center">
      <a class="navbar-brand" href="#"><img class="Logo rounded" src="../img/Logo.png" width="100px" /></a>
      <button
        class="navbar-toggler"
        type="button"
        data-bs-toggle="collapse"
        data-bs-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent"
        aria-expanded="false"
        aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0 nav-underline">
          <li class="nav-item">
            <a
              class="nav-link text-light"
              aria-current="page"
              href="../Accueil/Accueil.php">Accueil</a>
          </li>
          <li class="nav-item dropdown">
            <a
              class="nav-link text-light"
              href="../voiture/voiture.php"
              role="button"
              data-bs-toggle="dropdown"
              aria-expanded="false">
              Voitures
            </a>
            <ul class="dropdown-menu" data-bs-theme="dark">
              <li>
                <a class="dropdown-item" href="../voiture/voiture.php">Voitures</a>
              </li>
              <li>
                <hr class="dropdown-divider" />
              </li>
              <li><a class="dropdown-item" href="../voiture/Nissan/modelenissan.php">Nissan</a></li>
              <li><a class="dropdown-item" href="../voiture/Ford/modeleford.php">Ford</a></li>
              <li><a class="dropdown-item" href="../voiture/BMW/modelebmw.php">BMW</a></li>
              <li><a class="dropdown-item" href="../voiture/Porsche/modele Porsche.php">Porshe</a></li>
            </ul>
          </li>
          <li class="nav-item">
            <a class="nav-link active text-light" href="../essai/essai.php">Demande d'Essai</a>
          </li>
          <li class="nav-item">
            <a
              class="nav-link text-light"
              href="../Evenement/evenement.php">Évenement</a>
          </li>
          <li class="nav-item">
            <a
              class="nav-link text-light"
              href="../contact/Contact.php">Contact</a>
          </li>
        </ul>
        <!-- Utiliser la session pour afficher un boutton de deconnexion quand connecté -->
        <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in']) { ?>
          <div class="d-grid gap-2 d-md-flex justify-content-md-end">
            <form method="post" action="../includes/logout.php">
              <button class="btn btn-danger rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;"
                type="submit" name="logout"><img width="15px" src="../img/se-deconnecter.png"> </button>
            </form>
            <button type="button" class="btn btn-primary rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;"
              data-bs-toggle="modal" data-bs-target="#exampleModalcon">
              <img width="15px" src="../img/profile.png" />
            </button>
          </div>

        <?php } else { ?>
          <div class="dropdown">
            <button
              class="btn btn-primary rounded-circle d-flex align-items-center justify-content-center"
              style="width: 40px; height: 40px;"
              type="button"
              data-bs-toggle="dropdown"
              aria-expanded="false">
              <img class="Logo" src="../img/login.png" width="15px" />
            </button>
            <ul
              class="dropdown-menu dropdown-menu-end dropdow-menu-lg-start"
              data-bs-theme="dark">
              <li>
                <button class="dropdown-item" type="button">
                  <a
                    class="dropdown-item"
                    href="../inscription/inscription.php">Inscription</a>
                </button>
              </li>
              <li>
                <button class="dropdown-item" type="button">
                  <a
                    class="dropdown-item"
                    href="../inscription/connexion.php">Connexion</a>
                </button>
              </li>
            </ul>
          </div>
        <?php } ?>
      </div>
    </div>
  </nav>

  <!--Fin nav --->'
  <!-- arrière plan video -->
  <div class="background-container">
    <video autoplay muted loop class="background-video">
      <source src="../img/voitures/dmustang.mp4" type="video/mp4">
    </video>
  </div>

  <!--- Fin video -->
  <br /><br />
  <!--Debut demande d'essai-->
  <?php
  $connexion = mysqli_connect("localhost", "root", "", "supercar");
  $query = "SELECT * FROM voiture WHERE Marque IN ('BMW', 'NISSAN', 'FORD', 'PORSCHE')";
  $result = mysqli_query($connexion, $query);

  // Organiser les résultats par marque
  $voitures_par_marque = [];
  while ($res = mysqli_fetch_assoc($result)) {
    $voitures_par_marque[$res['Marque']][] = $res['Modele'];
  }
  ?>
  <br /><br /><br />
  <form class="bg-dark text-light bg-opacity-50" id="form1" data-bs-theme="dark" action="insertion.php" method="post">
    <h2 style="font-family:Copperplate, Copperplate Gothic Light, fantasy;" id="demande">Demande d'essai</h2>
    <?php
    if (isset($_SESSION['status']) && $_SESSION['status'] != '') {
      echo '<h4 style="color: aqua; font-family: Copperplate;">' . $_SESSION['status'] . '</h4>';
      unset($_SESSION['status']);
    }
    ?>
    <br />
    <hr width="100%">
    <label for="modele">Modele de voiture :</label>

    <select id="modele" name="modele" required>
      <?php foreach ($voitures_par_marque as $marque => $modeles) { ?>
        <optgroup label="<?php echo $marque; ?>">
          <?php foreach ($modeles as $modele) { ?>
            <option value="<?php echo $modele; ?>"><?php echo $modele; ?></option>
          <?php } ?>
        </optgroup>
      <?php } ?>
    </select>
    <label for="date">Date de la demande :</label>
    <input type="date" id="input1" name="date" min="<?php echo date('Y-m-d'); ?>" required />
    <label for="heure">Heure de la demande :</label>
    <input type="time" id="input1" name="heure" min="07:00" max="19:00" required />

    <br />
    <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in']) { ?>
      <button type="submit" class="btn btn-primary">Confirmer</button>
    <?php } else { ?>
      <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#essaiModal">
        Confirmer
      </button>
    <?php } ?>
    <!-- Modal -->
    <div class="modal fade" id="essaiModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h1 class="modal-title fs-5" id="exampleModalLabel">Vous n'êtes pas connecté</h1>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            Veuillez vous connecter ou vous inscrire.
          </div>
          <div class="modal-footer">
            <a href="../inscription/inscription.php"><button type="button" class="btn btn-secondary">S'inscrire</button></a>
            <a href="../inscription/connexion.php"><button type="button" class="btn btn-primary">Se connecter</button></a>
          </div>
        </div>
      </div>
    </div>
  </form>
  <br />
  <!--fin demande d'essai-->
  <?php
  include('..\includes\footer.php');
  ?>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <!-- Modal -->
  <div data-bs-theme="dark" class="modal fade" id="exampleModalcon" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title text-light fs-5" id="exampleModalLabel">Information Utilisateur</h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <p class="text-light">Nom: <?php echo  $_SESSION["Utilisateur"]; ?></p>
          <p class="text-light">Email: <?php echo  $_SESSION["mail"]; ?></p>
        </div>

      </div>
    </div>
  </div>
  <!-- Fin Modal -->
</body>

</html>