<?php
session_start();
// mettre en ligne la connexion avec la base de données
include("connexion.php");

// récupérer les contenus des variables formulaires
$modele = $_POST["modele"];
$nom = $_SESSION["Utilisateur"];
$date = $_POST["date"];
$heure = $_POST["heure"];

// Combiner date et heure pour créer un timestamp
$form_datetime = $date . ' ' . $heure;

// Récupérer la date et l'heure actuelles
$current_datetime = date('Y-m-d H:i:s');

// Comparer la date et l'heure du formulaire avec la date actuelle
if (strtotime($form_datetime) <= strtotime($current_datetime)) {
    // La demande est invalide car la date et/ou l'heure sont égales ou inférieures à l'actuelle
    $_SESSION['status'] = "La demande est invalide : la date ou l'heure sont dépassées.";
    $_SESSION['status_code'] = "error";
    header('Location: essai.php');
    exit();
} else {

    // préparer votre requête pour insérer des données dans la table PERSONNE
    $inserer = "INSERT INTO essai (Modele, Utilisateur, Date_demande, Heure, demandetemp) 
 VALUES ('$modele', '$nom', '$date', '$heure', NOW())";


    // exécuter la requête avec la focntion PHP
    $query_run = mysqli_query($bdd, $inserer);


    // fermeture de la connexion avec la base de données
    mysqli_close($bdd);

    if ($query_run) {
        $_SESSION['status'] = "Votre demande a été envoyée";
        $_SESSION['status_code'] = "success";
        header('Location: demande.php');
    } else {
        $_SESSION['status'] = "Erreur lors de l'envoie";
        $_SESSION['status_code'] = "error";
        header('Location: demande.php');
    }


    header('location: essai.php');
}
?>
<!-- vérifiez dans la base si vos données sont bien insérées avec phphmyadmin -->