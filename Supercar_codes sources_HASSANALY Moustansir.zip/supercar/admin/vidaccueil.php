<?php
session_start();
include('includes/header.php');
include_once('database/dbconfig.php');

?>

<div class="container-fluid">

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"> Modifier les donnees de la Page </h6>
        </div>

        <div class="card-body">
            <?php
            $connexion = mysqli_connect("localhost", "root", "", "adminpanel");
            if (isset($_POST['edit_btn'])) {
                $id = $_POST['edit_id'];
                $nom_table = $_POST['ntable'];

                $query = "SELECT * FROM $nom_table WHERE id='$id' ";
                $result = mysqli_query($connexion, $query);

                foreach ($result as $res) {
            ?>

                    <form action="code.php" method="post">

                        <input type="hidden" name="ntable" value="<?php echo $nom_table; ?>">
                        <input type="hidden" name="edit_id" value="<?php echo $res['id']; ?>">
                        <div class="form-group">
                            <label>video (La video doit être dans le dossier voitures)</label>
                            <input type="file" name="vid" value="<?php echo $res['vid']; ?>" class="form-control" placeholder="Enter le chemin de la video">
                        </div>

                        <br />
                        <a href="accueil.php" class="btn btn-danger"> ANNULER</a>
                        <button type="submit" name="updatevid" class="btn btn-primary"> Sauvegarder </button>

                    </form>
            <?php
                }
            }
            ?>

        </div>
    </div>
</div>

</div>
<!-- /.container-fluid -->


<?php
include('includes/scripts.php');
include('includes/footer.php');
?>