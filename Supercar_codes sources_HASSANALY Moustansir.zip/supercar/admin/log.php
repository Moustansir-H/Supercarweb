<?php
include('security.php');
include('includes/header.php');
include('includes/navbar.php');
?>




<div class="container-fluid">

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Log</h6>
        </div>

        <div class="card-body">

            <?php

            if (isset($_SESSION['success']) && $_SESSION['success'] != '') {
                echo '<h2>' . $_SESSION['success'] . '</h2>';
                unset($_SESSION['success']);
            }

            if (isset($_SESSION['status']) && $_SESSION['status'] != '') {
                echo '<h2>' . $_SESSION['status'] . '</h2>';
                unset($_SESSION['status']);
            }
            ?>

            <div class="table-responsive">

                <?php
                $nom_table = "auth_log";
                $connexion = mysqli_connect("localhost", "root", "", "supercar");
                $query = "SELECT * FROM $nom_table ORDER BY log_id ASC";
                $result = mysqli_query($connexion, $query);
                ?>

                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th> User-id </th>
                            <th> Nom utilisateur </th>
                            <th> Date </th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        while ($res = mysqli_fetch_array($result)) {
                        ?>
                            <tr>
                                <td> <?php echo $res['user_id']; ?> </td>
                                <td> <?php echo $res['username']; ?> </td>
                                <td> <?php echo $res['login_date']; ?> </td>
                            </tr>
                        <?php
                        }

                        ?>

                    </tbody>
                </table>

            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

<?php
include('includes/scripts.php');
include('includes/footer.php');
?>