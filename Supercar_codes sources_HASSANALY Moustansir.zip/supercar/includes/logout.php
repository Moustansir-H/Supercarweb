<?php
session_start();
unset($_SESSION["logged_in"]);
header("Location: ../inscription/connexion.php"); // Rediriger vers la page de connexion après la déconnexion
exit;
